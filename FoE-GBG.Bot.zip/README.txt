1) Step:
Download .NET6 SDK from following website and install it:
https://dotnet.microsoft.com/download

2) Step:
Locate the extension folder from FoE-GBG helper, it's named "Chrome_Extension". 

Go to chrome://extensions in the target Chrome browser and enable "Developer mode" by the checkbox in the upper right.
Press "Load unpacked extension..." and choose the version-number folder inside the desired extension folder.

The extension should now be loaded.

3) Step:
Edit config.json-file with text-editor and add your personal license-key into the "-character, see license-property for it.

4) Step:
Start BotNix.App.exe as Administrator OR on Linux-/MacOS with sudo dotnet BotNix.App.dll - do not forget so switch into
the right directoy BEFORE you execute command!

After all required data is loaded, the following message appears:
Backend-Service is active!

Bot is ready for usage now!

5) Step:
Go into the game, otherwise refresh the page with F5-Key and open JavaScript-Console. Press Command+Option+J (Mac) or 
Control+Shift+J (Windows, Linux, Chrome OS) to open the Console, right here on this very page.

6) Step:
Press F2-Key to enable-/disable FoE-GBG Bot - you can interrupt each attack with it, if you want. Go into Guild-Battleground,
choose any sector and attack it, with auto-battle - thats all. Bot will attack automatic like your settings for max. lose/win turns
and max. besieger points. ;-)