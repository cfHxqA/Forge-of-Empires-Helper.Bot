1) Step:
Download .NET7 SDK from following website and install it:
https://dotnet.microsoft.com/download

2) Step: (Chrome-/Brave browser) 
Locate the extension folder from FoE-GBG helper, it's named "Chrome_Extension". 

Go to chrome://extensions in the target Chrome browser and enable "Developer mode" by the checkbox in the upper right.
Press "Load unpacked extension..." and choose the target folder.

The extension should now be loaded.

2) Step: (Firefox browser) 
Locate the extension folder from FoE-GBG helper, it's named "Firefox_Extension". 

Go to about:debugging#/runtime/this-firefox in the target Firefox browser.
Press "Load Temporary Add-on" and choose the target folder.

The extension should now be loaded.


3) Step:
Edit config.json-file with text-editor and add your personal license-key into the "-character, see license-property for it.

4) Step:
Start on windows "BotNix.App.exe" as administrator OR on Linux-/MacOS with "sudo dotnet BotNix.App.dll" - do not forget so switch into
the right directoy BEFORE you execute command! (on MacOS open terminal at folder)

After all required data is loaded, the following message appears:
Backend-Service is active!

Bot is ready for usage now!

5) Step:
Go into the game, otherwise refresh the page with F5-Key - note the output in the application itself.

6) Step:
Press F2-Key to interrupt running attack or another action, like siege, defense. Go into Guild-Battleground/Guild Continents,
choose any sector and attack it, with auto-battle - thats all. Bot will attack automatic like your settings for max. lose/win turns
and max. besieger points. ;-)