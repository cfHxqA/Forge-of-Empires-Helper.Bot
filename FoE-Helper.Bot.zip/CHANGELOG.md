﻿# CHANGELOG_2024_07_24

+ Changes Configuration,
  - Added, 'guild_expedition.min_player_medals' - option to limit buy refills by player-medals amount
  - Patch, functional processes optimized and algorithms improved

# CHANGELOG_2024_07_15

+ Changes Configuration,
  - Patch, functional processes optimized and algorithms improved
  - Patch, official support game-version v1.286 & v1.287