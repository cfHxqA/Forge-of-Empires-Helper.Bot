﻿# CHANGELOG_2024_06_17

+ Changes Configuration,
  - Patch, functional processes optimized and algorithms improved
  - Patch, official support game-version v1.284 & v1.285