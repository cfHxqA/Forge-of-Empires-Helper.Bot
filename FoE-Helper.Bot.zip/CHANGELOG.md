﻿# CHANGELOG_2024_06_09

+ Changes Configuration,
  - Added, battleground, shortcut to enable/disable berserk-mode temporary
  - Patch, functional processes optimized and algorithms improved