﻿# CHANGELOG_2024_04_14

+ Changes Configuration,
  - Added, Guild-Battleground, unit specification allows declare "min_attrition"-attribute
  - Added, Guild-Battleground, unit specification allows declare "max_attrition"-attribute
  - Added, Guild-Battleground, displays information if your current attrition get changed while fighting
  - Fixed, Auto-Snipe, issue with auto-snipe again after certain of specific time