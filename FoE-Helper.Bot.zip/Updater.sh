#!/bin/bash

# Setze Zielordner, Archiv-URL und Archiv-Dateiname
targetfolder='$(pwd)'
archive_url='https://github.com/cfHxqA/Forge-of-Empires-Helper.Bot/raw/main/FoE-Helper.Bot.zip'

# Extrahiere den Archiv-Dateinamen aus der URL
archive_file="$targetfolder/$(basename "$archive_url")"

# Temporärer Ordner für die Extraktion
tempfolder="$targetfolder/temp"

# Dateien, die nicht ersetzt werden sollen
skip_files=('config.json' 'config.mscc' 'config.conf')

# Überprüfen, ob .NET 10 SDK installiert ist
echo 'Checking if .NET 10 SDK is installed...'
if ! dotnet --list-sdks | grep -i '10.' > /dev/null; then
    echo '.NET 10 SDK not found. Installing now...'

    # .NET SDK 10 für Linux herunterladen und installieren
    sudo apt-get update
    sudo apt-get install -y dotnet-sdk-10.0
    
    # Überprüfen, ob die Installation erfolgreich war
    if ! dotnet --list-sdks | grep -i '10.' > /dev/null; then
        echo 'Error: .NET 10 SDK installation failed.'
        exit 1
    else
        echo '.NET 10 SDK installed successfully.'
    fi
fi

# Lade das Archiv herunter
echo "Downloading archive from $archive_url..."
wget -O "$archive_file" "$archive_url"

# Erstelle temporären Ordner
echo 'Extracting archive...'
mkdir -p "$tempfolder"

# Entpacke das Archiv
echo 'Extracting the archive...'
unzip "$archive_file" -d "$tempfolder"

# Ersetze Dateien aus dem Archiv, außer config.json, config.mscc und config.conf
echo 'Replacing files in the target folder, skipping config.json, config.mscc, and config.conf...'

for file in "$tempfolder"/*; do
    targetfile="$targetfolder/$(basename "$file")"

    # Überprüfen, ob die Datei in der Ausschlussliste ist
    skip=0
    for skip_file in "${skip_files[@]}"; do
        if [[ "$(basename "$file")" == "$skip_file" ]]; then
            skip=1
            break
        fi
    done

    # Wenn die Datei nicht in der Ausschlussliste ist, ersetze sie
    if [[ $skip -ne 1 ]]; then
        echo "Replacing: $targetfile"
        cp -f "$file" "$targetfile"
    else
        echo "Skipping: $targetfile"
    fi
done

# Temporären Ordner aufräumen
rm -rf "$tempfolder"

# Archiv löschen
rm -f "$archive_file"

echo 'Done!'